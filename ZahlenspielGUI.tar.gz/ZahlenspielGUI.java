import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class ZahlenspielGUI extends JFrame implements ActionListener {
    private Random random;
    private int zielzahl;
    private int versuche;
    private boolean gewonnen;
    private JLabel label;
    private JTextField eingabeField;
    private JButton rateButton;

    public ZahlenspielGUI() {
        random = new Random();
        zielzahl = random.nextInt(100) + 1;
        versuche = 0;
        gewonnen = false;

        setTitle("Zahlenspiel");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300, 150);
        setLayout(new FlowLayout());

        label = new JLabel("Gib eine Zahl zwischen 1 und 100 ein:");
        add(label);

        eingabeField = new JTextField(10);
        add(eingabeField);

        rateButton = new JButton("Rate");
        rateButton.addActionListener(this);
        add(rateButton);

        setVisible(true);
    }

    public static void main(String[] args) {
        new ZahlenspielGUI();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == rateButton) {
            int eingabe;
            try {
                eingabe = Integer.parseInt(eingabeField.getText());
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Ungültige Eingabe! Bitte gib eine ganze Zahl ein.");
                return;
            }
            versuche++;

            if (eingabe == zielzahl) {
                gewonnen = true;
                JOptionPane.showMessageDialog(this, "Glückwunsch! Du hast die Zahl " + zielzahl + " erraten.\nDu hast " + versuche + " Versuche gebraucht.");
                System.exit(0);
            } else if (eingabe < zielzahl) {
                JOptionPane.showMessageDialog(this, "Zu niedrig! Versuche es erneut.");
            } else {
                JOptionPane.showMessageDialog(this, "Zu hoch! Versuche es erneut.");
            }
        }
    }
}
